import { useState, useEffect } from 'react'
import { api } from './api'

// ── Icons (inline SVG) ─────────────────────────────────────

const icons = {
    dashboard: (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" />
            <rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" />
        </svg>
    ),
    users: (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" />
            <path d="M22 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" />
        </svg>
    ),
    entries: (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
            <polyline points="14 2 14 8 20 8" /><line x1="16" y1="13" x2="8" y2="13" />
            <line x1="16" y1="17" x2="8" y2="17" /><polyline points="10 9 9 9 8 9" />
        </svg>
    ),
    events: (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
        </svg>
    ),
    settings: (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" />
        </svg>
    ),
    partners: (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" />
            <path d="M23 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" />
        </svg>
    ),
    payments: (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect x="2" y="5" width="20" height="14" rx="2" /><line x1="2" y1="10" x2="22" y2="10" />
        </svg>
    ),
}

const TABS = [
    { id: 'users', label: 'Юзеры', icon: icons.users },
    {
        id: 'menu', label: 'Меню', icon: (
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="3" y1="12" x2="21" y2="12" /><line x1="3" y1="6" x2="21" y2="6" /><line x1="3" y1="18" x2="21" y2="18" />
            </svg>
        )
    },
]

// ── Menu Page ───────────────────────────────────────────────

function MenuPage({ onNavigate }) {
    const menuItems = [
        { id: 'entries', label: '📓 Записи', desc: 'Все записи дневника' },
        { id: 'dashboard', label: '📊 Дашборд', desc: 'Статистика и метрики' },
        { id: 'partners', label: '🤝 Партнеры', desc: 'Реферальная программа' },
        { id: 'payments', label: '💰 Оплаты', desc: 'Настройки шлюзов' },
        { id: 'logs', label: '📜 Логи', desc: 'События системы' },
        { id: 'settings', label: '⚙️ Настройки', desc: 'Провайдеры и ключи' },
    ]

    return (
        <div className="page">
            <h1 className="page-title">Меню</h1>
            <div className="stats-grid" style={{ gridTemplateColumns: '1fr' }}>
                {menuItems.map((item) => (
                    <div key={item.id} className="card clickable" onClick={() => onNavigate(item.id)} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                        <div>
                            <div className="card-title" style={{ marginBottom: 4 }}>{item.label}</div>
                            <div className="card-subtitle">{item.desc}</div>
                        </div>
                        <div style={{ color: 'var(--text-secondary)' }}>→</div>
                    </div>
                ))}
            </div>
        </div>
    )
}




// ── Toast ───────────────────────────────────────────────────

function Toast({ message, type, onClose }) {
    useEffect(() => {
        const t = setTimeout(onClose, 3000)
        return () => clearTimeout(t)
    }, [onClose])

    return <div className={`toast toast-${type}`}>{message}</div>
}

// ── Dashboard Page ──────────────────────────────────────────

function DashboardPage() {
    const [data, setData] = useState(null)
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        api.getDashboard().then(setData).catch(console.error).finally(() => setLoading(false))
    }, [])

    if (loading) return <div className="loading"><div className="spinner"></div> Загрузка...</div>
    if (!data) return <div className="loading">Ошибка загрузки</div>

    return (
        <div className="page">
            <h1 className="page-title">📊 Дашборд</h1>
            <div className="stats-grid">
                <div className="card">
                    <div className="card-title">DAU</div>
                    <div className="card-value">{data.dau}</div>
                    <div className="card-subtitle">активных сегодня</div>
                </div>
                <div className="card">
                    <div className="card-title">WAU</div>
                    <div className="card-value">{data.wau}</div>
                    <div className="card-subtitle">за 7 дней</div>
                </div>
                <div className="card">
                    <div className="card-title">Записи сегодня</div>
                    <div className="card-value">{data.entries_today}</div>
                </div>
                <div className="card">
                    <div className="card-title">Всего юзеров</div>
                    <div className="card-value">{data.total_users}</div>
                </div>
            </div>

            <div className="section-header">
                <h2 className="section-title">Использование (7 дней)</h2>
            </div>
            <div className="stats-grid">
                <div className="card">
                    <div className="card-title">🎤 Голос</div>
                    <div className="card-value">{data.voice_count_7d}</div>
                </div>
                <div className="card">
                    <div className="card-title">📝 Текст</div>
                    <div className="card-value">{data.text_count_7d}</div>
                </div>
            </div>

            {data.errors_7d > 0 && (
                <div className="card" style={{ borderColor: 'var(--destructive)' }}>
                    <div className="card-title">⚠️ Ошибки (7 дней)</div>
                    <div className="card-value" style={{ color: 'var(--destructive)' }}>{data.errors_7d}</div>
                </div>
            )}
        </div>
    )
}

// ── Users Page ──────────────────────────────────────────────

// ── Users Page ──────────────────────────────────────────────

function UsersPage({ onSelectUser }) {
    const [users, setUsers] = useState([])
    const [search, setSearch] = useState('')
    const [loading, setLoading] = useState(true)
    const [showAdd, setShowAdd] = useState(false)

    const fetchUsers = () => {
        setLoading(true)
        api.getUsers(search).then(setUsers).catch(console.error).finally(() => setLoading(false))
    }

    useEffect(() => {
        fetchUsers()
    }, [search])

    return (
        <div className="page">
            <div className="section-header">
                <h1 className="page-title" style={{ margin: 0 }}>👥 Пользователи</h1>
                <button className="btn btn-primary" onClick={() => setShowAdd(true)}>+ Добавить</button>
            </div>

            <div className="input-group">
                <input
                    className="input"
                    placeholder="Поиск по имени/username..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                />
            </div>

            {loading ? (
                <div className="loading"><div className="spinner"></div></div>
            ) : (
                users.map((u) => (
                    <div key={u.id} className="list-item clickable" onClick={() => onSelectUser(u.id)}>
                        <div className="list-item-avatar">
                            {(u.first_name || u.username || '?')[0].toUpperCase()}
                        </div>
                        <div className="list-item-content">
                            <div className="list-item-title">
                                {u.first_name || u.username || `ID ${u.tg_user_id}`}
                            </div>
                            <div className="list-item-subtitle">
                                @{u.username || '—'} · {u.locale} · {u.timezone} · <b>${u.balance || 0}</b>
                            </div>
                        </div>
                        <span className={`badge ${u.role === 'admin' ? 'badge-warning' : 'badge-info'}`}>
                            {u.role}
                        </span>
                    </div>
                ))
            )}

            {showAdd && <UserAddModal onClose={() => setShowAdd(false)} onAdded={fetchUsers} />}
        </div>
    )
}

function UserAddModal({ onClose, onAdded }) {
    const [form, setForm] = useState({ tg_user_id: '', username: '', first_name: '', role: 'user' })
    const [loading, setLoading] = useState(false)

    const handleSubmit = async (e) => {
        e.preventDefault()
        setLoading(true)
        try {
            await api.createUser({ ...form, tg_user_id: parseInt(form.tg_user_id) })
            onAdded()
            onClose()
        } catch (err) { alert(err.message) }
        setLoading(false)
    }

    return (
        <div className="modal-overlay">
            <div className="card modal-content">
                <div className="card-title">Новый пользователь</div>
                <form onSubmit={handleSubmit}>
                    <div className="input-group">
                        <label>Telegram ID (обязательно)</label>
                        <input className="input" type="number" required value={form.tg_user_id} onChange={(e) => setForm({ ...form, tg_user_id: e.target.value })} />
                    </div>
                    <div className="input-group">
                        <label>Username (без @)</label>
                        <input className="input" value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} />
                    </div>
                    <div className="input-group">
                        <label>Имя</label>
                        <input className="input" value={form.first_name} onChange={(e) => setForm({ ...form, first_name: e.target.value })} />
                    </div>
                    <div style={{ display: 'flex', gap: 10, marginTop: 20 }}>
                        <button type="submit" className="btn btn-primary" disabled={loading}>Добавить</button>
                        <button type="button" className="btn btn-secondary" onClick={onClose}>Отмена</button>
                    </div>
                </form>
            </div>
        </div>
    )
}

// ── User Details Page ───────────────────────────────────────

function UserDetailsPage({ userId, onBack }) {
    const [data, setData] = useState(null)
    const [entries, setEntries] = useState([])
    const [loading, setLoading] = useState(true)
    const [isEditing, setIsEditing] = useState(false)
    const [editForm, setEditForm] = useState({})
    const [showTopup, setShowTopup] = useState(false)
    const [showLimits, setShowLimits] = useState(false)
    const [entryToEdit, setEntryToEdit] = useState(null)
    const [showAddEntry, setShowAddEntry] = useState(false)

    const fetchData = () => {
        setLoading(true)
        Promise.all([
            api.getUser(userId),
            api.getEntries({ user_id: userId })
        ]).then(([u, e]) => {
            setData(u)
            setEntries(e)
            setEditForm(u.user)
        }).catch(console.error).finally(() => setLoading(false))
    }

    useEffect(() => fetchData(), [userId])

    if (loading && !data) return <div className="loading"><div className="spinner"></div></div>
    if (!data) return <div className="loading">Пользователь не найден</div>

    const u = data.user

    const handleUpdateUser = async (patch) => {
        try {
            await api.updateUser(userId, patch)
            fetchData()
            setIsEditing(false)
        } catch (e) { alert(e.message) }
    }

    const handleDeleteEntry = async (entryId) => {
        if (!confirm('Удалить эту запись безвозвратно?')) return
        try {
            await api.deleteEntry(entryId)
            setEntries(entries.filter(e => e.id !== entryId))
        } catch (e) { console.error(e) }
    }

    return (
        <div className="page">
            <div className="section-header">
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <button className="btn btn-secondary" onClick={onBack} style={{ padding: '8px 12px' }}>
                        ←
                    </button>
                    <h1 className="page-title" style={{ margin: 0 }}>{u.first_name || u.username} ({u.role})</h1>
                </div>
                <div style={{ display: 'flex', gap: 10 }}>
                    <button className="btn btn-primary" onClick={() => setShowAddEntry(true)}>+ Запись</button>
                    <button className="btn btn-secondary" onClick={() => setIsEditing(!isEditing)}>
                        {isEditing ? 'Отмена' : '✎ Править'}
                    </button>
                </div>
            </div>

            {isEditing ? (
                <div className="card">
                    <div className="card-title">Редактирование</div>
                    <div className="input-group">
                        <label>Имя</label>
                        <input className="input" value={editForm.first_name || ''} onChange={(e) => setEditForm({ ...editForm, first_name: e.target.value })} />
                    </div>
                    <div className="input-group">
                        <label>Username</label>
                        <input className="input" value={editForm.username || ''} onChange={(e) => setEditForm({ ...editForm, username: e.target.value })} />
                    </div>
                    <div className="input-group">
                        <label>Язык</label>
                        <select className="input" value={editForm.locale} onChange={(e) => setEditForm({ ...editForm, locale: e.target.value })}>
                            <option value="ru">Русский (ru)</option>
                            <option value="en">English (en)</option>
                        </select>
                    </div>
                    <div className="input-group">
                        <label>Таймзона</label>
                        <input className="input" value={editForm.timezone} onChange={(e) => setEditForm({ ...editForm, timezone: e.target.value })} />
                    </div>
                    <button className="btn btn-primary" onClick={() => handleUpdateUser(editForm)}>Сохранить изменения</button>
                </div>
            ) : (
                <div className="card">
                    <div className="card-title">Инфо</div>
                    <div className="stats-grid">
                        <div><b>TG ID:</b> {u.tg_user_id}</div>
                        <div><b>Роль:</b> {u.role}</div>
                        <div><b>Язык:</b> {u.locale}</div>
                        <div><b>Таймзона:</b> {u.timezone}</div>
                        <div><b>Статус:</b> <span className={`badge ${u.status === 'active' ? 'badge-success' : 'badge-error'}`}>{u.status}</span></div>
                    </div>

                    <div style={{ display: 'flex', gap: 10, marginTop: 15 }}>
                        <button
                            className={`btn ${u.status === 'active' ? 'btn-secondary' : 'btn-primary'}`}
                            onClick={() => handleUpdateUser({ status: u.status === 'active' ? 'blocked' : 'active' })}
                            style={{ border: u.status === 'active' ? '1px solid var(--destructive)' : '' }}
                        >
                            {u.status === 'active' ? '⛔ Заблокировать' : '✅ Разблокировать'}
                        </button>
                        <button
                            className="btn btn-secondary"
                            onClick={() => handleUpdateUser({ role: u.role === 'admin' ? 'user' : 'admin' })}
                        >
                            {u.role === 'admin' ? '👤 Сделать юзером' : '👑 Сделать админом'}
                        </button>
                    </div>
                    <div style={{ display: 'flex', gap: 10, marginTop: 10 }}>
                        <button className="btn btn-primary" onClick={() => setShowTopup(true)}>💰 Пополнить баланс</button>
                        <button className="btn btn-secondary" onClick={() => setShowLimits(true)}>⚡ Лимиты</button>
                    </div>
                </div>
            )}

            <div className="stats-grid">
                <div className="card">
                    <div className="card-title">Использование сегодня</div>
                    <div className="stat-value">{data.usage_today.entries} зап.</div>
                    <div className="stat-value">{data.usage_today.stt_seconds} сек STT</div>
                </div>
            </div>

            <h2 className="section-title">Записи пользователя</h2>
            {entries.length === 0 ? (
                <div className="loading">Нет записей</div>
            ) : (
                entries.map((e) => (
                    <div key={e.id} className="card">
                        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                            <span className={`badge ${e.status === 'ok' ? 'badge-success' : 'badge-error'}`}>{e.status}</span>
                            <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                                <span className="card-subtitle">{new Date(e.created_at).toLocaleString('ru-RU')}</span>
                                <button className="btn clickable" style={{ padding: '2px 6px', fontSize: 10, color: 'var(--accent)' }} onClick={() => setEntryToEdit(e)}>
                                    📝 Править
                                </button>
                                <button
                                    className="btn clickable"
                                    style={{ padding: '2px 6px', fontSize: 10, color: 'var(--destructive)' }}
                                    onClick={() => handleDeleteEntry(e.id)}
                                >
                                    Удалить
                                </button>
                            </div>
                        </div>
                        <pre className="entry-text">{e.final_diary_text}</pre>
                    </div>
                ))
            )}
            {showTopup && <TopupModal userId={userId} onClose={() => setShowTopup(false)} onDone={fetchData} />}
            {showLimits && <LimitsModal userId={userId} initialLimits={u.limit_overrides || {}} onClose={() => setShowLimits(false)} onDone={fetchData} />}
            {(entryToEdit || showAddEntry) && (
                <EntryEditModal
                    userId={userId}
                    entry={entryToEdit}
                    onClose={() => { setEntryToEdit(null); setShowAddEntry(false); }}
                    onDone={fetchData}
                />
            )}
        </div>
    )
}

// ── Entries Page ────────────────────────────────────────────

function EntriesPage() {
    const [entries, setEntries] = useState([])
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        api.getEntries().then(setEntries).catch(console.error).finally(() => setLoading(false))
    }, [])

    return (
        <div className="page">
            <h1 className="page-title">📓 Записи дневника</h1>
            {loading ? (
                <div className="loading"><div className="spinner"></div></div>
            ) : entries.length === 0 ? (
                <div className="loading">Записей пока нет</div>
            ) : (
                entries.map((e) => (
                    <div key={e.id} className="card">
                        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                            <span className={`badge ${e.status === 'ok' ? 'badge-success' : 'badge-error'}`}>
                                {e.status}
                            </span>
                            <div style={{ display: 'flex', gap: 5 }}>
                                {e.is_admin_entry && <span className="badge badge-error" style={{ background: 'var(--accent)' }}>ADMIN</span>}
                                <span className={`badge badge-info`}>{e.input_type}</span>
                            </div>
                        </div>
                        {e.raw_input_text && (
                            <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginBottom: 8 }}>
                                📥 {e.raw_input_text}
                            </div>
                        )}
                        <pre className="entry-text">
                            {e.final_diary_text || '(нет текста)'}
                        </pre>
                        <div className="card-subtitle" style={{ marginTop: 8 }}>
                            {e.created_at ? new Date(e.created_at).toLocaleString('ru-RU') : ''}
                        </div>
                    </div>
                ))
            )}
        </div>
    )
}

// ── Events Page ─────────────────────────────────────────────

function EventsPage() {
    const [events, setEvents] = useState([])
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        api.getEvents().then(setEvents).catch(console.error).finally(() => setLoading(false))
    }, [])

    return (
        <div className="page">
            <h1 className="page-title">⚡ Поток событий</h1>
            {loading ? (
                <div className="loading"><div className="spinner"></div></div>
            ) : (
                events.map((e) => (
                    <div key={e.id} className="event-item">
                        <span className="event-time">
                            {e.created_at ? new Date(e.created_at).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }) : ''}
                        </span>
                        <div>
                            <span className="event-name">{e.event_name}</span>
                            {e.payload && Object.keys(e.payload).length > 0 && (
                                <div style={{ fontSize: 11, color: 'var(--text-secondary)', marginTop: 2 }}>
                                    {JSON.stringify(e.payload)}
                                </div>
                            )}
                        </div>
                    </div>
                ))
            )}
        </div>
    )
}

// ── Settings Page ───────────────────────────────────────────

function SettingsPage() {
    const [provider, setProvider] = useState('gemini')
    const [model, setModel] = useState('gemini-2.0-flash')
    const [assemblyKey, setAssemblyKey] = useState('')
    const [openaiKey, setOpenaiKey] = useState('')
    const [geminiKey, setGeminiKey] = useState('')
    const [systemPrompt, setSystemPrompt] = useState('')
    const [userTemplate, setUserTemplate] = useState('')
    const [repairPrompt, setRepairPrompt] = useState('')
    const [toast, setToast] = useState(null)
    const [loading, setLoading] = useState(false)

    const showToast = (message, type = 'success') => setToast({ message, type })

    useEffect(() => {
        api.getSettings().then(s => {
            if (s.llm_provider) setProvider(s.llm_provider.value)
            if (s.llm_model) setModel(s.llm_model.value)
            // We don't set keys as they are masked
            if (s.system_prompt) setSystemPrompt(s.system_prompt.value)
            if (s.user_template) setUserTemplate(s.user_template.value)
            if (s.repair_prompt) setRepairPrompt(s.repair_prompt.value)
        })
    }, [])

    const saveProviders = async () => {
        setLoading(true)
        try {
            await api.updateProviders({ llm_provider: provider, llm_model: model })
            showToast('Провайдер обновлён!')
        } catch (e) { showToast(e.message, 'error') }
        setLoading(false)
    }

    const saveSecrets = async () => {
        setLoading(true)
        try {
            const data = {}
            if (assemblyKey) data.assemblyai_api_key = assemblyKey
            if (openaiKey) data.openai_api_key = openaiKey
            if (geminiKey) data.gemini_api_key = geminiKey
            await api.updateSecrets(data)
            showToast('Ключи сохранены!')
            setAssemblyKey('')
            setOpenaiKey('')
            setGeminiKey('')
        } catch (e) { showToast(e.message, 'error') }
        setLoading(false)
    }

    const savePrompts = async () => {
        setLoading(true)
        try {
            await api.updatePrompts({
                system_prompt: systemPrompt,
                user_template: userTemplate,
                repair_prompt: repairPrompt
            })
            showToast('Промты обновлены!')
        } catch (e) { showToast(e.message, 'error') }
        setLoading(false)
    }

    return (
        <div className="page">
            <h1 className="page-title">⚙️ Настройки</h1>

            {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

            {/* Provider selection */}
            <div className="card">
                <div className="card-title">🤖 LLM провайдер</div>
                <div className="input-group">
                    <label>Провайдер</label>
                    <select className="input" value={provider} onChange={(e) => setProvider(e.target.value)}>
                        <option value="gemini">Google Gemini</option>
                        <option value="openai">OpenAI ChatGPT</option>
                    </select>
                </div>
                <div className="input-group">
                    <label>Модель</label>
                    <input className="input" value={model} onChange={(e) => setModel(e.target.value)}
                        placeholder="gemini-2.0-flash / gpt-4o" />
                </div>
                <button className="btn btn-primary" onClick={saveProviders} disabled={loading}>
                    Сохранить
                </button>
            </div>

            {/* API Keys */}
            <div className="card">
                <div className="card-title">🔑 API ключи</div>
                <div className="input-group">
                    <label>AssemblyAI API Key</label>
                    <input className="input" type="password" value={assemblyKey}
                        onChange={(e) => setAssemblyKey(e.target.value)} placeholder="Новый ключ..." />
                </div>
                <div className="input-group">
                    <label>OpenAI API Key</label>
                    <input className="input" type="password" value={openaiKey}
                        onChange={(e) => setOpenaiKey(e.target.value)} placeholder="Новый ключ..." />
                </div>
                <div className="input-group">
                    <label>Gemini API Key</label>
                    <input className="input" type="password" value={geminiKey}
                        onChange={(e) => setGeminiKey(e.target.value)} placeholder="Новый ключ..." />
                </div>
                <button className="btn btn-primary" onClick={saveSecrets} disabled={loading}>
                    Сохранить ключи
                </button>
            </div>

            {/* Prompts */}
            <div className="card">
                <div className="card-title">📝 Промты</div>
                <div className="input-group">
                    <label>System Prompt</label>
                    <textarea className="input" value={systemPrompt}
                        onChange={(e) => setSystemPrompt(e.target.value)}
                        placeholder="Оставьте пустым для использования дефолтного..." />
                </div>
                <div className="input-group">
                    <label>User Template</label>
                    <textarea className="input" value={userTemplate}
                        onChange={(e) => setUserTemplate(e.target.value)}
                        placeholder="Переменные: {local_datetime}, {timezone}, {location}, {input_type}, {raw_text}" />
                </div>
                <div className="input-group">
                    <label>Repair Prompt</label>
                    <textarea className="input" value={repairPrompt}
                        onChange={(e) => setRepairPrompt(e.target.value)}
                        placeholder="Промт для исправления формата..." />
                </div>
                <button className="btn btn-primary" onClick={savePrompts} disabled={loading}>
                    Сохранить промты
                </button>
            </div>
        </div>
    )
}

// ── App Shell ───────────────────────────────────────────────

// ── Login Page ─────────────────────────────────────────────

function LoginPage({ onLogin }) {
    const [pass, setPass] = useState('')
    const [error, setError] = useState('')

    const handleSubmit = async (e) => {
        e.preventDefault()
        localStorage.setItem('admin_password', pass)
        try {
            await api.getMe()
            onLogin()
        } catch (err) {
            setError('Неверный пароль')
            localStorage.removeItem('admin_password')
        }
    }

    return (
        <div className="page" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', minHeight: '100vh', textAlign: 'center' }}>
            <h1>🛡️ Вход в админку</h1>
            <p style={{ color: 'var(--text-secondary)', marginBottom: 20 }}>
                Для доступа к панели введите пароль администратора.
            </p>
            <form onSubmit={handleSubmit} className="card" style={{ maxWidth: 320, margin: '0 auto' }}>
                <input
                    type="password"
                    className="input"
                    placeholder="Пароль"
                    value={pass}
                    onChange={(e) => setPass(e.target.value)}
                    autoFocus
                />
                {error && <div style={{ color: 'var(--destructive)', fontSize: 13, marginTop: 8 }}>{error}</div>}
                <button type="submit" className="button" style={{ marginTop: 15, width: '100%' }}>
                    Войти
                </button>
            </form>
        </div>
    )
}

// ── Affiliate Program ───────────────────────────────────────

function PartnersPage() {
    const [stats, setStats] = useState(null)
    const [rate, setRate] = useState('0.2')
    const [minOut, setMinOut] = useState('10')
    const [loading, setLoading] = useState(true)
    const [toast, setToast] = useState(null)

    const fetchAll = () => {
        setLoading(true)
        Promise.all([
            api.getAffiliateStats(),
            api.getSettings()
        ]).then(([s, settings]) => {
            setStats(s)
            if (settings.affiliate_commission_rate) setRate(settings.affiliate_commission_rate.value)
            if (settings.affiliate_min_withdrawal) setMinOut(settings.affiliate_min_withdrawal.value)
        }).catch(console.error).finally(() => setLoading(false))
    }

    useEffect(() => fetchAll(), [])

    const handleSave = async () => {
        setLoading(true)
        try {
            await api.updateAffiliateSettings({
                affiliate_commission_rate: rate,
                affiliate_min_withdrawal: minOut
            })
            setToast({ message: 'Настройки партнеров сохранены!', type: 'success' })
        } catch (e) { setToast({ message: e.message, type: 'error' }) }
        setLoading(false)
    }

    if (!stats && loading) return <div className="loading"><div className="spinner"></div></div>

    return (
        <div className="page">
            <h1 className="page-title">🤝 Партнерская программа</h1>
            {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

            <div className="stats-grid">
                <div className="card">
                    <div className="card-subtitle">Всего партнеров</div>
                    <div className="stat-value">{stats?.total_partners || 0}</div>
                </div>
                <div className="card">
                    <div className="card-subtitle">Рефералов</div>
                    <div className="stat-value">{stats?.total_referrals || 0}</div>
                </div>
                <div className="card">
                    <div className="card-subtitle">Выплачено всего</div>
                    <div className="stat-value">${stats?.total_paid || 0}</div>
                </div>
            </div>

            <div className="card">
                <div className="card-title">Настройки программы</div>
                <div className="input-group">
                    <label>Комиссия (0.2 = 20%)</label>
                    <input className="input" type="number" step="0.01" value={rate} onChange={e => setRate(e.target.value)} />
                </div>
                <div className="input-group">
                    <label>Минимальная выплата ($)</label>
                    <input className="input" type="number" value={minOut} onChange={e => setMinOut(e.target.value)} />
                </div>
                <button className="btn btn-primary" onClick={handleSave} disabled={loading}>Сохранить условия</button>
            </div>
        </div>
    )
}

// ── Payments Page ──────────────────────────────────────────

function PaymentsPage() {
    const [loading, setLoading] = useState(false)
    const [toast, setToast] = useState(null)
    const [form, setForm] = useState({
        yoomoney_shop_id: '',
        yoomoney_secret: '',
        robokassa_merchant_id: '',
        robokassa_password_1: '',
        robokassa_password_2: '',
        cryptobot_token: ''
    })

    useEffect(() => {
        api.getSettings().then(s => {
            setForm({
                yoomoney_shop_id: s.yoomoney_shop_id?.value || '',
                yoomoney_secret: '',
                robokassa_merchant_id: s.robokassa_merchant_id?.value || '',
                robokassa_password_1: '',
                robokassa_password_2: '',
                cryptobot_token: ''
            })
        }).catch(console.error)
    }, [])

    const handleSave = async () => {
        setLoading(true)
        try {
            await api.updatePaymentSettings(form)
            setToast({ message: 'Настройки платежей обновлены!', type: 'success' })
        } catch (e) { setToast({ message: e.message, type: 'error' }) }
        setLoading(false)
    }

    return (
        <div className="page">
            <h1 className="page-title">💰 Прием платежей</h1>
            {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

            <div className="card">
                <div className="card-title">ЮMoney (ЮKassa)</div>
                <div className="input-group">
                    <label>Shop ID</label>
                    <input className="input" value={form.yoomoney_shop_id} onChange={e => setForm({ ...form, yoomoney_shop_id: e.target.value })} />
                </div>
                <div className="input-group">
                    <label>Секретный ключ (API Key)</label>
                    <input className="input" type="password" value={form.yoomoney_secret} onChange={e => setForm({ ...form, yoomoney_secret: e.target.value })} placeholder="Оставьте пустым, если не меняете..." />
                </div>
            </div>

            <div className="card">
                <div className="card-title">Robokassa</div>
                <div className="input-group">
                    <label>Идентификатор магазина</label>
                    <input className="input" value={form.robokassa_merchant_id} onChange={e => setForm({ ...form, robokassa_merchant_id: e.target.value })} />
                </div>
                <div className="input-group">
                    <label>Пароль #1</label>
                    <input className="input" type="password" value={form.robokassa_password_1} onChange={e => setForm({ ...form, robokassa_password_1: e.target.value })} />
                </div>
                <div className="input-group">
                    <label>Пароль #2</label>
                    <input className="input" type="password" value={form.robokassa_password_2} onChange={e => setForm({ ...form, robokassa_password_2: e.target.value })} />
                </div>
            </div>

            <div className="card">
                <div className="card-title">@CryptoBot (Telegram)</div>
                <div className="input-group">
                    <label>CryptoPay API Token</label>
                    <input className="input" type="password" value={form.cryptobot_token} onChange={e => setForm({ ...form, cryptobot_token: e.target.value })} placeholder="Оставьте пустым, если не меняете..." />
                </div>
            </div>

            <div className="card">
                <div className="card-title">@CryptoBot (Telegram)</div>
                <div className="input-group">
                    <label>CryptoPay API Token</label>
                    <input className="input" type="password" value={form.cryptobot_token} onChange={e => setForm({ ...form, cryptobot_token: e.target.value })} placeholder="Оставьте пустым, если не меняете..." />
                </div>
            </div>

            <button className="btn btn-primary" onClick={handleSave} disabled={loading}>
                {loading ? 'Сохранение...' : 'Сохранить все ключи'}
            </button>
        </div>
    )
}

// ── Modals ──────────────────────────────────────────────────

function TopupModal({ userId, onClose, onDone }) {
    const [amount, setAmount] = useState(10)
    const [loading, setLoading] = useState(false)

    const handleSub = async (e) => {
        e.preventDefault()
        setLoading(true)
        try {
            await api.topUpUser(userId, parseFloat(amount))
            onDone()
            onClose()
        } catch (err) { alert(err.message) }
        setLoading(false)
    }

    return (
        <div className="modal-overlay">
            <div className="card modal-content">
                <div className="card-title">Пополнение баланса</div>
                <form onSubmit={handleSub}>
                    <div className="input-group">
                        <label>Сумма ($)</label>
                        <input className="input" type="number" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} />
                    </div>
                    <div style={{ display: 'flex', gap: 10, marginTop: 20 }}>
                        <button type="submit" className="btn btn-primary" disabled={loading}>Пополнить</button>
                        <button type="button" className="btn btn-secondary" onClick={onClose}>Отмена</button>
                    </div>
                </form>
            </div>
        </div>
    )
}

function LimitsModal({ userId, initialLimits, onClose, onDone }) {
    const [limits, setLimits] = useState(initialLimits)
    const [loading, setLoading] = useState(false)

    const handleSub = async (e) => {
        e.preventDefault()
        setLoading(true)
        try {
            await api.updateUserLimits(userId, limits)
            onDone()
            onClose()
        } catch (err) { alert(err.message) }
        setLoading(false)
    }

    return (
        <div className="modal-overlay">
            <div className="card modal-content">
                <div className="card-title">Лимиты пользователя</div>
                <form onSubmit={handleSub}>
                    <div className="input-group">
                        <label>Записей в день</label>
                        <input className="input" type="number" value={limits.entries_count || ''} onChange={(e) => setLimits({ ...limits, entries_count: parseInt(e.target.value) })} />
                    </div>
                    <div className="input-group">
                        <label>Секунд STT в день</label>
                        <input className="input" type="number" value={limits.stt_seconds || ''} onChange={(e) => setLimits({ ...limits, stt_seconds: parseInt(e.target.value) })} />
                    </div>
                    <div style={{ display: 'flex', gap: 10, marginTop: 20 }}>
                        <button type="submit" className="btn btn-primary" disabled={loading}>Сохранить</button>
                        <button type="button" className="btn btn-secondary" onClick={onClose}>Отмена</button>
                    </div>
                </form>
            </div>
        </div>
    )
}

function EntryEditModal({ userId, entry, onClose, onDone }) {
    const [text, setText] = useState(entry?.final_diary_text || '')
    const [loading, setLoading] = useState(false)

    const handleSub = async (e) => {
        e.preventDefault()
        setLoading(true)
        try {
            if (entry) {
                await api.updateEntry(entry.id, { text })
            } else {
                await api.createEntry({ user_id: userId, text })
            }
            onDone()
            onClose()
        } catch (err) { alert(err.message) }
        setLoading(false)
    }

    return (
        <div className="modal-overlay">
            <div className="card modal-content" style={{ width: '90%', maxWidth: 600 }}>
                <div className="card-title">{entry ? 'Редактировать запись' : 'Новая запись'}</div>
                <form onSubmit={handleSub}>
                    <div className="input-group">
                        <textarea
                            className="input"
                            style={{ height: 300, fontSize: 13 }}
                            value={text}
                            onChange={(e) => setText(e.target.value)}
                            placeholder="Текст записи..."
                        />
                    </div>
                    <div style={{ display: 'flex', gap: 10, marginTop: 20 }}>
                        <button type="submit" className="btn btn-primary" disabled={loading}>
                            {entry ? 'Обновить' : 'Создать'}
                        </button>
                        <button type="button" className="btn btn-secondary" onClick={onClose}>Отмена</button>
                    </div>
                </form>
            </div>
        </div>
    )
}


// ── App Shell ───────────────────────────────────────────────

export default function App() {
    const [page, setPage] = useState('users')
    const [selectedUser, setSelectedUser] = useState(null)
    const [isAuth, setIsAuth] = useState(null)

    useEffect(() => {
        try {
            window.Telegram?.WebApp?.ready()
            window.Telegram?.WebApp?.expand()
        } catch { }

        api.getMe()
            .then(() => setIsAuth(true))
            .catch(() => setIsAuth(false))
    }, [])

    const handleSelectUser = (id) => {
        setSelectedUser(id)
        setPage('user-detail')
    }

    const renderPage = () => {
        switch (page) {
            case 'users': return <UsersPage onSelectUser={handleSelectUser} />
            case 'user-detail': return <UserDetailsPage userId={selectedUser} onBack={() => setPage('users')} />
            case 'entries': return <EntriesPage />

            // Menu pages
            case 'menu': return <MenuPage onNavigate={setPage} />
            case 'dashboard': return <DashboardPage />
            case 'partners': return <PartnersPage />
            case 'payments': return <PaymentsPage />
            case 'logs': return <EventsPage />
            case 'settings': return <SettingsPage />

            default: return <UsersPage onSelectUser={handleSelectUser} />
        }
    }

    // Determine which tab is active based on current page
    const getActiveTab = () => {
        if (page === 'users' || page === 'user-detail') return 'users'
        return 'menu' // active for entries, menu, dashboard, partners, payments, logs, settings
    }

    if (isAuth === null) return <div className="loading"><div className="spinner"></div></div>
    if (isAuth === false) return <LoginPage onLogin={() => setIsAuth(true)} />

    const activeTab = getActiveTab()

    return (
        <div className="app">
            <div className="content">
                {renderPage()}
            </div>
            <nav className="bottom-nav">
                {TABS.map((t) => (
                    <button
                        key={t.id}
                        className={`nav-item ${activeTab === t.id ? 'active' : ''}`}
                        onClick={() => setPage(t.id)}
                    >
                        {t.icon}
                        {t.label}
                    </button>
                ))}
            </nav>
        </div>
    )
}
