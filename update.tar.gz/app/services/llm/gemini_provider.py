"""
Google Gemini LLM provider — uses google.genai SDK.
"""

from __future__ import annotations

import logging

from google import genai
from google.genai import types

from app.config import settings
from app.dto.llm import LLMRequestDTO, LLMResultDTO
from app.services.llm.base import BaseLLMProvider

logger = logging.getLogger(__name__)


class GeminiProvider(BaseLLMProvider):
    def __init__(self, api_key: str = "", model: str = ""):
        self._api_key = api_key or settings.GEMINI_API_KEY
        self._model = model or settings.GEMINI_MODEL
        self._client = genai.Client(api_key=self._api_key)

    async def generate(self, request: LLMRequestDTO) -> LLMResultDTO:
        logger.info("Gemini: generating for request %s (model=%s)", request.request_id, self._model)

        try:
            response = self._client.models.generate_content(
                model=self._model,
                contents=request.user_prompt,
                config=types.GenerateContentConfig(
                    system_instruction=request.system_prompt,
                    temperature=request.temperature,
                    max_output_tokens=request.max_tokens,
                ),
            )

            text = response.text or ""
            usage = response.usage_metadata
            tokens_in = usage.prompt_token_count if usage else 0
            tokens_out = usage.candidates_token_count if usage else 0

            logger.info("Gemini: response %d tokens_in, %d tokens_out", tokens_in, tokens_out)

            return LLMResultDTO(
                request_id=request.request_id,
                provider="gemini",
                model=self._model,
                final_text=text.strip(),
                status="ok",
                tokens_in=tokens_in,
                tokens_out=tokens_out,
            )

        except Exception as e:
            logger.exception("Gemini generation failed")
            return LLMResultDTO(
                request_id=request.request_id,
                provider="gemini",
                model=self._model,
                status="error",
                error_code="gemini_error",
                error_message=str(e),
            )
