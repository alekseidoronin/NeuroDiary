"""
Telegram webhook handler — receives update, normalises, runs pipeline.
"""

from __future__ import annotations

import logging
from uuid import uuid4

from aiogram import Bot, Dispatcher, Router, F
from aiogram.types import Message, ContentType, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from aiogram.filters import Command
from aiogram.enums import ParseMode
from aiogram.enums import ParseMode
from sqlalchemy import select, func

from app.config import settings
from app.db.engine import async_session
from app.db.models import User, TelegramUpdate, BotSettings, Subscription, JournalEntry
from app.dto.telegram import InputNormalizedDTO
from app.services.pipeline import process_message
from app.services.events import log_event
from app.services.prompts import SYSTEM_PROMPT
from app.api.middleware import SubscriptionMiddleware

logger = logging.getLogger(__name__)

router = Router()
router.message.middleware(SubscriptionMiddleware())
router.callback_query.middleware(SubscriptionMiddleware())

TG_MSG_LIMIT = 4096

def _split_for_telegram(text: str, limit: int = TG_MSG_LIMIT) -> list[str]:
    """Split a long text into Telegram-safe chunks, respecting line boundaries.
    If there are multiple chunks, each gets a 'Часть X/N' header.
    """
    if len(text) <= limit:
        return [text]

    lines = text.split('\\n')
    chunks: list[str] = []
    current_chunk: list[str] = []
    current_len = 0
    # Reserve space for part header like '\\n\\n<i>Часть 1/3</i>'
    header_reserve = 30

    for line in lines:
        line_len = len(line) + 1  # +1 for newline
        if current_len + line_len > limit - header_reserve and current_chunk:
            chunks.append('\\n'.join(current_chunk))
            current_chunk = [line]
            current_len = line_len
        else:
            current_chunk.append(line)
            current_len += line_len

    if current_chunk:
        chunks.append('\\n'.join(current_chunk))

    total = len(chunks)
    if total <= 1:
        return chunks

    return [
        f"{chunk}\\n\\n<i>Часть {i+1}/{total}</i>"
        for i, chunk in enumerate(chunks)
    ]

async def _check_limits(db, user: User) -> bool:
    """Check if user is allowed to create new entry (5 free entries limit)."""
    # 1. Check active subscription
    stmt_sub = select(Subscription).where(
        Subscription.user_id == user.id,
        Subscription.status.in_(['active', 'trial'])
    )
    has_sub = (await db.execute(stmt_sub)).scalar_one_or_none()
    
    if has_sub:
        return True
        
    # 2. Check entry count
    stmt_count = select(func.count(JournalEntry.id)).where(JournalEntry.user_id == user.id)
    count = (await db.execute(stmt_count)).scalar() or 0
    
    return count < 5

# ── Keyboards ───────────────────────────────────────────────

def get_main_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⚙️ Мой стиль (Промпт)", callback_data="settings_prompt")],
        [InlineKeyboardButton(text="📤 Экспорт записей", callback_data="export_entries")],
        [InlineKeyboardButton(text="❓ Помощь", callback_data="help_info")],
    ])

def get_prompt_settings_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        # [InlineKeyboardButton(text="✏️ Изменить", callback_data="prompt_edit")], # Removed, just show instruction
        [InlineKeyboardButton(text="🔄 Сбросить к стандартному", callback_data="prompt_reset")],
        [InlineKeyboardButton(text="🔙 Назад", callback_data="menu_back")],
    ])

# ── /start ───────────────────────────────────────────────────

START_TEXT = """
👋 <b>Я — твой AI-дневник.</b>

Я помогаю сохранять важные моменты, структурируя твои мысли.

🎤 <b>Что я умею:</b>
1. Принимаю голосовые и текстовые заметки.
2. Превращаю их в структурированный дневник.
3. Сохраняю всё в надежном месте.

🎁 <b>Для новых пользователей доступно 5 бесплатных записей.</b>

👇 <b>Начни прямо сейчас — отправь мне сообщение!</b>
"""

@router.message(Command("start"))
async def cmd_start(message: Message) -> None:
    async with async_session() as db:
        user = await _ensure_user(db, message)
        if user.status in ("blocked", "deleted"):
             await message.answer("⛔ Ваш аккаунт отключен. Обратитесь к администратору @AlexD_GOLD.")
             return

        await log_event(db, "user_started", user.id)
        await db.commit()
    await message.answer(START_TEXT, parse_mode=ParseMode.HTML, reply_markup=get_main_keyboard())


@router.callback_query(F.data == "menu_back")
async def cb_menu_back(call: CallbackQuery):
    await call.message.edit_text(START_TEXT, parse_mode=ParseMode.HTML, reply_markup=get_main_keyboard())
    await call.answer()


@router.callback_query(F.data == "help_info")
async def cb_help_info(call: CallbackQuery):
    text = (
        "❓ <b>Как это работает?</b>\n\n"
        "1. Ты отправляешь мне <b>текст</b> или <b>голосовое</b>.\n"
        "2. Я обрабатываю это через мощную нейросеть.\n"
        "3. Я сохраняю результат в твою базу записей.\n\n"
        "Ты можешь выгрузить свои записи кнопкой «Экспорт».\n"
        "Настрой «Мой стиль», чтобы я писал так, как тебе нравится!"
    )
    await call.message.edit_text(text, parse_mode=ParseMode.HTML, reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔙 Назад", callback_data="menu_back")]
    ]))
    await call.answer()


@router.callback_query(F.data == "settings_prompt")
async def cb_settings_prompt(call: CallbackQuery):
    async with async_session() as db:
        user = await _ensure_user(db, call) # Ensure user exists
        if user.status in ("blocked", "deleted"):
            await call.answer("⛔ Аккаунт отключен. Пишите @AlexD_GOLD", show_alert=True)
            return
        current = user.custom_system_prompt or "<i>(используется стандартный стиль)</i>"
    
    text = (
        f"🎨 <b>Твой текущий стиль (System Prompt):</b>\n\n"
        f"{current}\n\n"
        "Чтобы <b>изменить</b> стиль, отправь мне команду:\n"
        "<code>/set_my_prompt Твой новый текст промпта</code>\n\n"
        "Например: <i>/set_my_prompt Пиши кратко, сухо, используй списки.</i>"
    )
    await call.message.edit_text(text, parse_mode=ParseMode.HTML, reply_markup=get_prompt_settings_keyboard())
    await call.answer()


@router.callback_query(F.data == "prompt_reset")
async def cb_prompt_reset(call: CallbackQuery):
    async with async_session() as db:
        user = await _ensure_user(db, call)
        if user.status in ("blocked", "deleted"):
            await call.answer("⛔ Аккаунт отключен. Пишите @AlexD_GOLD", show_alert=True)
            return
        user.custom_system_prompt = None
        await db.commit()
        await log_event(db, "user_prompt_reset", user.id)

    await call.answer("✅ Стиль сброшен к стандартному", show_alert=True)
    await cb_settings_prompt(call) # Refresh view


@router.callback_query(F.data == "export_entries")
async def cb_export_entries(call: CallbackQuery):
    await call.answer("🔍 Ищу записи...")
    # Reuse export logic but for callback
    from app.db.models import JournalEntry

    async with async_session() as db:
        user = await _ensure_user(db, call)
        if user.status in ("blocked", "deleted"):
            await call.answer("⛔ Аккаунт отключен. Пишите @AlexD_GOLD", show_alert=True)
            return

        result = await db.execute(
            select(JournalEntry)
            .where(JournalEntry.user_id == user.id)
            .where(JournalEntry.status == "ok")
            .where(JournalEntry.is_admin_entry == False)
            .order_by(JournalEntry.created_at.desc())
            .limit(5)
        )
        entries = result.scalars().all()

    if not entries:
        await call.message.answer("📭 У тебя пока нет записей.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="🗑 Скрыть", callback_data="delete_msg")]]))
        return

    for entry in reversed(entries):
        text = entry.final_diary_text or "(пусто)"
        try:
            await call.message.answer(text, parse_mode=ParseMode.HTML)
        except Exception:
            await call.message.answer(text)
    
    await call.message.answer("☝️ Это твои последние 5 записей.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="🗑 Скрыть", callback_data="delete_msg")]]))


@router.callback_query(F.data == "delete_msg")
async def cb_delete_msg(call: CallbackQuery):
    await call.message.delete()
    await call.answer()


# ── Legacy Commands (Hidden) ────────────────────────────────

@router.message(Command("prompt"))
async def cmd_prompt(message: Message) -> None:
    async with async_session() as db:
        user = await _ensure_user(db, message)
        if user.role != "admin": return
        from app.services.settings import DynamicSettings
        ds = DynamicSettings(db)
        p = await ds.get_system_prompt()
        await message.answer(f"System Prompt:\n{p}")

@router.message(Command("set_prompt"))
async def cmd_set_prompt(message: Message) -> None:
    # Admin only
    async with async_session() as db:
        user = await _ensure_user(db, message)
        if user.role != "admin": return
        new_prompt = message.text.replace("/set_prompt", "", 1).strip()
        if not new_prompt:
             await message.answer("Empty prompt.")
             return
        from app.db.models import BotSettings
        res = await db.execute(select(BotSettings).where(BotSettings.key == "system_prompt"))
        setting = res.scalar_one_or_none()
        if not setting:
            db.add(BotSettings(key="system_prompt", value=new_prompt, updated_by=user.id))
        else:
            setting.value = new_prompt
            setting.updated_by = user.id
            setting.version += 1
        await db.commit()
        await message.answer("Global prompt updated.")

@router.message(Command("my_prompt"))
async def cmd_my_prompt(message: Message) -> None:
    # Just redirect to settings menu logic
    async with async_session() as db:
        user = await _ensure_user(db, message)
        current = user.custom_system_prompt or "<i>(стандартный)</i>"
    await message.answer(f"Твой промпт:\n{current}", parse_mode=ParseMode.HTML)

@router.message(Command("set_my_prompt"))
async def cmd_set_my_prompt(message: Message) -> None:
    new_prompt = message.text.replace("/set_my_prompt", "", 1).strip()
    if not new_prompt:
        await message.answer("⚠️ Использование: <code>/set_my_prompt Текст...</code>", parse_mode=ParseMode.HTML)
        return
    if len(new_prompt) > 2000:
        await message.answer("⚠️ Слишком длинный текст.")
        return
    async with async_session() as db:
        user = await _ensure_user(db, message)
        user.custom_system_prompt = new_prompt
        await db.commit()
        await log_event(db, "user_prompt_updated", user.id)
    await message.answer("✅ <b>Твой стиль обновлен!</b>\nТеперь я буду придерживаться этих правил.", parse_mode=ParseMode.HTML)

@router.message(Command("reset_my_prompt"))
async def cmd_reset_my_prompt(message: Message) -> None:
    async with async_session() as db:
        user = await _ensure_user(db, message)
        user.custom_system_prompt = None
        await db.commit()
    await message.answer("✅ Стиль сброшен к стандартному.")

@router.message(Command("export"))
async def cmd_export(message: Message) -> None:
    # Legacy handler, alias to callback logic
    await message.answer("Используй кнопку в меню /start для экспорта.")


# ── Voice / Audio handler ───────────────────────────────────

@router.message(F.content_type.in_({ContentType.VOICE, ContentType.AUDIO}))
async def handle_voice(message: Message) -> None:
    voice = message.voice or message.audio
    if voice is None:
        await message.answer("⚠️ Не удалось получить аудиофайл.")
        return

    duration = voice.duration or 0
    if duration > settings.MAX_VOICE_DURATION_SECONDS:
         # check role inside
         pass 

    processing_msg = await message.answer("🎧 <b>Слушаю и обрабатываю...</b>", parse_mode=ParseMode.HTML)

    async with async_session() as db:
        user = await _ensure_user(db, message)
        
        if user.status in ("blocked", "deleted"):
             await processing_msg.edit_text("⛔ Ваш аккаунт отключен. Обратитесь к администратору @AlexD_GOLD.")
             return

        if not await _check_limits(db, user):
             await processing_msg.edit_text("🔒 <b>Лимит исчерпан!</b>\n\nВам было доступно 5 бесплатных записей. Чтобы продолжить, обратитесь к администратору @AlexD_GOLD.", parse_mode="HTML")
             return

        if duration > settings.MAX_VOICE_DURATION_SECONDS and user.role != "admin":
             await processing_msg.edit_text(f"⚠️ Слишком длинное голосовое ({duration}с). Лимит {settings.MAX_VOICE_DURATION_SECONDS}с.")
             return

        # Check dedup
        if await _is_duplicate(db, message):
            return

        inp = InputNormalizedDTO(
            tg_user_id=message.from_user.id,
            chat_id=message.chat.id,
            message_id=message.message_id,
            input_type="voice" if message.voice else "audio",
            telegram_file_id=voice.file_id,
            voice_duration=duration,
            locale=message.from_user.language_code or "ru",
            timezone=user.timezone or settings.DEFAULT_TIMEZONE,
            username=message.from_user.username,
        )

        await log_event(db, "message_received", user.id, {
            "input_type": inp.input_type,
            "duration": duration,
        })
        await db.commit()

        try:
            result = await process_message(db, inp, user)
        except Exception as e:
            logger.error(f"Processing error: {e}", exc_info=True)
            await processing_msg.edit_text("⚠️ Ошибка обработки. Попробуйте позже.")
            return

    parts = _split_for_telegram(result["text"])
    try:
        await processing_msg.edit_text(parts[0], parse_mode=ParseMode.HTML)
    except Exception as e:
        logger.error(f"HTML error: {e}")
        await processing_msg.edit_text(parts[0])
    
    for part in parts[1:]:
        try:
            await message.answer(part, parse_mode=ParseMode.HTML)
        except Exception:
            await message.answer(part)


# ── Text message handler ────────────────────────────────────

@router.message(F.text)
async def handle_text(message: Message) -> None:
    user_text = (message.text or "").strip()
    if not user_text:
        return
    
    # Ignore commands
    if user_text.startswith("/"):
        return

    processing_msg = await message.answer("✍️ <b>Читаю и оформляю...</b>", parse_mode=ParseMode.HTML)

    async with async_session() as db:
        user = await _ensure_user(db, message)
        
        if user.status in ("blocked", "deleted"):
             await processing_msg.edit_text("⛔ Ваш аккаунт отключен. Обратитесь к администратору @AlexD_GOLD.")
             return

        if not await _check_limits(db, user):
             await processing_msg.edit_text("🔒 <b>Лимит исчерпан!</b>\n\nВам было доступно 5 бесплатных записей. Чтобы продолжить, обратитесь к администратору @AlexD_GOLD.", parse_mode="HTML")
             return

        if await _is_duplicate(db, message):
            return

        inp = InputNormalizedDTO(
            tg_user_id=message.from_user.id,
            chat_id=message.chat.id,
            message_id=message.message_id,
            input_type="text",
            raw_text=user_text,
            locale=message.from_user.language_code or "ru",
            timezone=user.timezone or settings.DEFAULT_TIMEZONE,
            username=message.from_user.username,
        )

        await log_event(db, "message_received", user.id, {"input_type": "text"})
        await db.commit()

        try:
            result = await process_message(db, inp, user)
        except Exception as e:
            logger.error(f"Processing error: {e}", exc_info=True)
            await processing_msg.edit_text("⚠️ Ошибка обработки.")
            return

    parts = _split_for_telegram(result["text"])
    try:
        await processing_msg.edit_text(parts[0], parse_mode=ParseMode.HTML)
    except Exception:
        await processing_msg.edit_text(parts[0])
    
    for part in parts[1:]:
        await message.answer(part, parse_mode=ParseMode.HTML)



# ── Helpers ──────────────────────────────────────────────────

async def _ensure_user(db, message: Message) -> User:
    """Get or create user in DB."""
    tg_id = message.from_user.id
    result = await db.execute(select(User).where(User.tg_user_id == tg_id))
    user = result.scalar_one_or_none()

    if user is None:
        user = User(
            tg_user_id=tg_id,
            username=message.from_user.username,
            first_name=message.from_user.first_name,
            locale=message.from_user.language_code or "ru",
            timezone=settings.DEFAULT_TIMEZONE,
            role="admin" if tg_id in settings.admin_user_ids else "user",
        )
        db.add(user)
        await db.flush()
        logger.info("New user created: tg_id=%s, db_id=%s", tg_id, user.id)

    return user


async def _is_duplicate(db, message: Message) -> bool:
    """Check if this update was already processed (dedup by message_id for simplicity)."""
    # We use a simple approach: check if journal entry with this message_id exists
    result = await db.execute(
        select(TelegramUpdate).where(TelegramUpdate.update_id == message.message_id)
    )
    if result.scalar_one_or_none():
        logger.info("Duplicate message %s — skipping", message.message_id)
        return True

    # Mark as processed
    db.add(TelegramUpdate(update_id=message.message_id, tg_user_id=message.from_user.id))
    await db.flush()
    return False
