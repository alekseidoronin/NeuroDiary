from typing import Any, Awaitable, Callable, Dict
import logging
from aiogram import BaseMiddleware
from aiogram.types import Message, CallbackQuery, TelegramObject
from aiogram.enums import ChatMemberStatus
from redis.asyncio import Redis
from sqlalchemy import select

from app.db.engine import async_session
from app.db.models import User
from app.config import settings

logger = logging.getLogger(__name__)

# Channel to check subscription for
REQUIRED_CHANNEL = "@Doronin_Al"

# Reuse Redis connection or create new pool?
# Ideally we should share it. But creating separate pool is safe.
redis = Redis.from_url(settings.REDIS_URL, decode_responses=True, encoding="utf-8")

class SubscriptionMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        user = None
        if isinstance(event, Message):
            user = event.from_user
        elif isinstance(event, CallbackQuery):
            user = event.from_user
        
        if not user:
            return await handler(event, data)

        # 1. Check DB Status (Priority: Ban > Subscription)
        try:
            async with async_session() as db:
                result = await db.execute(select(User.status).where(User.tg_user_id == user.id))
                db_status = result.scalar_one_or_none()
                
                # DEBUG LOG
                if isinstance(event, Message):
                    await event.answer(f"DEBUG: DB Status='{db_status}' (ID: {user.id})")

                if db_status and str(db_status).lower() in ("blocked", "deleted"):
                    msg = "⛔ Ваш доступ ограничен. Обратитесь к администратору @AlexD_GOLD"
                    if isinstance(event, Message):
                        await event.answer(msg)
                    elif isinstance(event, CallbackQuery):
                        await event.answer(msg, show_alert=True)
                    return
        except Exception as e:
            logger.error(f"DB check error in middleware: {e}")
            if isinstance(event, Message):
                await event.answer(f"⚠️ Ошибка доступа к БД: {e}")
            return # Stop processing on DB error

        cache_key = f"sub_check:{user.id}" # Restore key for potential use
        # try:
        #    is_subscribed = await redis.get(cache_key)
        # except Exception as e:
        #    logger.error(f"Redis get error: {e}")
        #    is_subscribed = None
        
        is_subscribed = False # FORCE CHECK for debugging
        
        if is_subscribed:
            return await handler(event, data)

        # Check Telegram API
        bot = data["bot"]
        try:
            member = await bot.get_chat_member(chat_id=REQUIRED_CHANNEL, user_id=user.id)
            
            # DEBUG LOG
            if isinstance(event, Message):
                await event.answer(f"DEBUG: Channel Status='{member.status}'")

            if member.status in [ChatMemberStatus.CREATOR, ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.MEMBER, ChatMemberStatus.RESTRICTED]:
                # Valid subscription
                # try:
                #     await redis.set(cache_key, "1", ex=300) # Cache for 5 minutes
                # except Exception as e:
                #     logger.error(f"Redis set error: {e}")
                
                return await handler(event, data)
            else:
                # Not subscribed
                text = (
                    f"🔒 <b>Доступ только для подписчиков!</b>\n\n"
                    f"Чтобы пользоваться ботом, подпишитесь на канал: {REQUIRED_CHANNEL}\n"
                    "После подписки отправьте любое сообщение.\n\n"
                    "<i>Если возникли проблемы — пишите @AlexD_GOLD</i>"
                )
                if isinstance(event, Message):
                    await event.answer(text, parse_mode="HTML")
                elif isinstance(event, CallbackQuery):
                    await event.answer("Подпишитесь на @Doronin_Al!", show_alert=True)
                return

        except Exception as e:
            # If check fails (e.g. bot banned in channel, or connection error), 
            # we should probably Log and Pass (allow access) to not break the bot entirely if channel issue occurs.
            # OR we block. User said "REQUIRED".
            # But if bot can't check, it's safer to allow or we lock everyone out on API error.
            # Let's log and allow for now, unless it's a specific "User not found" error.
            logger.error(f"Subscription check failed for {user.id}: {e}")
            # If we strictly follow requirements:
            # await event.answer(f"Ошибка проверки подписки: {e}. Попробуйте позже.")
            # return
            
            # Allow purely to avoid full blockage on bugs
            return await handler(event, data)
