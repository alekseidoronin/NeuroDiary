"""
Usage & billing service — checks limits before processing.
"""

from __future__ import annotations

import logging
from datetime import date
from typing import Optional
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.db.models import UsageDaily, Subscription, Plan, User

logger = logging.getLogger(__name__)


async def check_limits(db: AsyncSession, user: User) -> dict:
    """
    Check if the user is within their daily limits.
    Returns {"allowed": True/False, "reason": str | None, "plan": str}
    """
    if user.role == "admin":
        return {"allowed": True, "reason": None, "plan": "admin_unlimited"}

    user_id = user.id
    today = date.today()

    # Get active subscription
    sub_q = (
        select(Subscription, Plan)
        .join(Plan, Subscription.plan_id == Plan.id)
        .where(Subscription.user_id == user_id)
        .where(Subscription.status.in_(["trial", "active"]))
        .order_by(Subscription.created_at.desc())
        .limit(1)
    )
    result = await db.execute(sub_q)
    row = result.first()

    if row:
        sub, plan = row
        limits = plan.limits_json or {}
        plan_name = plan.code
    else:
        # Default trial limits from config
        limits = {
            "entries_per_day": settings.TRIAL_ENTRIES_PER_DAY,
            "stt_seconds_per_day": settings.TRIAL_STT_SECONDS_PER_DAY,
        }
        plan_name = "trial_default"

    # Get usage
    usage_q = select(UsageDaily).where(
        UsageDaily.user_id == user_id,
        UsageDaily.date == today,
    )
    result = await db.execute(usage_q)
    usage = result.scalar_one_or_none()

    if usage is None:
        return {"allowed": True, "reason": None, "plan": plan_name}

    max_entries = limits.get("entries_per_day", 999)
    max_stt = limits.get("stt_seconds_per_day", 9999)

    if usage.entries_count >= max_entries:
        return {
            "allowed": False,
            "reason": f"Лимит записей на сегодня исчерпан ({max_entries}/{max_entries}). Обновитесь на Pro!",
            "plan": plan_name,
        }

    if usage.stt_seconds >= max_stt:
        return {
            "allowed": False,
            "reason": f"Лимит транскрибации на сегодня исчерпан ({max_stt}с). Обновитесь на Pro!",
            "plan": plan_name,
        }

    return {"allowed": True, "reason": None, "plan": plan_name}


async def increment_usage(
    db: AsyncSession,
    user_id: UUID,
    entries: int = 0,
    stt_seconds: int = 0,
    tokens_in: int = 0,
    tokens_out: int = 0,
) -> None:
    """Increment daily usage counters (upsert)."""
    today = date.today()

    usage_q = select(UsageDaily).where(
        UsageDaily.user_id == user_id,
        UsageDaily.date == today,
    )
    result = await db.execute(usage_q)
    usage = result.scalar_one_or_none()

    if usage is None:
        usage = UsageDaily(
            user_id=user_id,
            date=today,
            entries_count=entries,
            stt_seconds=stt_seconds,
            tokens_in=tokens_in,
            tokens_out=tokens_out,
        )
        db.add(usage)
    else:
        usage.entries_count += entries
        usage.stt_seconds += stt_seconds
        usage.tokens_in += tokens_in
        usage.tokens_out += tokens_out

    await db.flush()
